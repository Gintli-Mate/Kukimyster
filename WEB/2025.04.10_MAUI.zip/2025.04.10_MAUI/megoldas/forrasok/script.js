let point = 0;

document.querySelector('input[type=Submit]').addEventListener('click', (e) => {
    e.preventDefault();
    point = 0;
    let radios = document.querySelectorAll('.correct');
    if(radios[0].checked)
        point++;
    if(radios[1].checked)
        point++;
    if(document.querySelector('#ev').value == 2022)
        point++;
    alert(point == 3 ? "Gratulálunk! Minden kérdésre helyesen válaszolt!" : "Nem tökéletes! :) Nézzen utána a válaszoknak az oldalon!");
    document.querySelector('#pont').innerHTML = point;
});