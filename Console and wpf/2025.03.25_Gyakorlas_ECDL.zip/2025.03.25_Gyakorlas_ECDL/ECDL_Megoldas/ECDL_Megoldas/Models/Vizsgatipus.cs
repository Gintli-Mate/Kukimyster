﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECDL_Megoldas.Models
{
    public class Vizsgatipus
    {
        public int Id { get; set; }
        public string? Modul { get; set; }
    }
}
