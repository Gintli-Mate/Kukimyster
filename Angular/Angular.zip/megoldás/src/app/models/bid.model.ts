export interface BidModel {
  paintingId: number;
  email: string;
  price: number;
}
